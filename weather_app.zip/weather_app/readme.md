Application Name- Weather_App
Framework-React
Weather API Name-https://www.weatherapi.com/
How to run-
open folder using vs code
open terminal from top of the vs code
type npm install command to install node modules
type npm start command to start the applcation
then browse http://localhost:3000/ to open the application